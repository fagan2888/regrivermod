class Solve:
    """
    Model solution class
    --------------------

    Contains functions for both dynamic programing and Q-learning

    """

    def __init__(self, para, users, storage):

        self.cores = para.CPU_CORES

        ##################      Estimate market demand curve    ###############

        GRID = 25
        points = GRID * GRID

        maxQ = para.K * (1 - para.delta1b) - para.delta1a
        maxI = (para.K * 2) / para.I_bar
        Q_grid = np.linspace(0, maxQ, GRID)
        I_grid = np.linspace(0, maxI, GRID)

        [Qi, Ii] = np.mgrid[0:GRID, 0:GRID]

        Q = Q_grid[Qi.flatten()]
        I = I_grid[Ii.flatten()]

        P = np.zeros(points)

        for i in range(points):
            a = Q[i] / users.N
            users.a = np.ones(users.N) * a
            users.demand_para(I[i])
            users.mv(I[i])
            P[i] = users.solve_price(Q[i], para.price, users.Pmax, users.t_cost)

        self.market_d = SMALL_Tilecode_m(points, 2, [21, 21], 15, random_offset=True)
        self.market_d.fit(np.array([Q, I]).T, P)

        #pylab.figure()
        #pylab.clf()
        #pylab.title('Market demand curve')
        #self.market_d.plot(['x', 1], showdata=True)
        #pylab.show()


        ##################      Estimate perfect market demand curve    ###############

        P_perf = np.zeros(points)

        for i in range(points):
            a = Q[i] / users.N
            users.a = np.ones(users.N) * a
            users.demand_para(I[i])
            users.mv(I[i])
            P_perf[i] = users.solve_price(Q[i], para.price, users.Pmax, 0)

        self.perf_market = SMALL_Tilecode_m(points, 2, [21, 21], 15, random_offset=True)
        self.perf_market.fit(np.array([Q, I]).T, P_perf)

        #import pickle
        #home = '/home/nealbob'
        #folder = '/Dropbox/Model/Results/chapter5/'
        #f = open(home + folder + 'Demand.pkl', 'wb')
        #pickle.dump([Q, I, P_perf], f)
        #f.close()

        #pylab.figure()
        #pylab.clf()
        #self.perf_market.plot(['x', 1], showdata = False)
        #pylab.show()

        ###################      Construct the planners payoff function     ##################

        # First calculate Social Welfare (SW) function 

        # Build grids 
        Q, I, SW = users.build_SW(para, self.perf_market, 50)
        points = len(Q)

        # Now estimate continuous approximation
        self.SW_f = SMALL_Tilecode_m(points, 2, [30, 30], 20, random_offset=True)
        self.SW_f.fit(np.array([Q, I]).T, SW, sgd=0, eta=0.5, scale=0, n_iters=2)

        # Plot fitted vs actual
        pylab.figure()
        pylab.clf()
        pylab.title('Social welfare function (planners payoff)')
        self.SW_f.plot(['x', 1], showdata=True)
        pylab.show()


        ##################    Construct discrete inflow probability distribution      ##################

        self.I_points = 20
        [self.I_grid, self.I_pr, self.I_bar] = 

        # Plot distribution
        #pylab.figure()
        #pylab.clf()
        #pylab.title('Inflow distribution')
        #pylab.plot(self.I_grid[10,:], self.I_pr[10,:])
        #pylab.show()

    #------------------------------------------------------------------------------------------------#
    #                                                                                                #
    #                 Stochastic Dynamic Programming - Planners Problem                              #
    #                                                                                                #
    #------------------------------------------------------------------------------------------------#


    def planner(self, storage, plot=False):
        """
        Solve the social planners problem. Policy iteration with function approximation
        :param storage: Storage instance
        :param plot: Boolean, show plots
        """

        #State space grid
        SGRID = 40
        S_grid = np.linspace(0, 1, SGRID) ** 1.2
        S_grid = S_grid * storage.K
        Imax = max(self.I_grid[0, :]) / self.I_bar

        I_grid = np.linspace(0, 1, self.I_points) * Imax
        [Si, Ii] = np.mgrid[0:SGRID, 0:self.I_points]
        S = S_grid[Si.flatten()]
        I = I_grid[Ii.flatten()]
        I_i = np.asarray(Ii.flatten(), dtype='int32')
        points = len(S)
        I_bar = storage.I_bar

        # Initialise functions

        self.V_f = SMALL_Tilecode_m(points, 2, [23, 11], 21, random_offset=True)
        self.V_f.fit(np.array([S, I]).T, np.zeros(points))

        self.sdp = SDP(S, I, self.SW_f, self.V_f, storage, self.beta, self.I_grid[0, :], self.I_pr, I_i, I_bar)

        tic = time.time()

        W_opt, self.V_f = self.sdp.policy_iteration(0.0004, 100)

        toc = time.time()
        print 'Solve time: ' + str(toc - tic)

        # Smooth functions for W* and P*
        self.W_f = SMALL_Tilecode_m(points, 2, [18, 9], 25, random_offset=True)
        self.W_f.fit(np.array([S, I]).T, W_opt, sgd=1, eta=0.4, n_iters=2, scale=0, score=True)

        # Plot results
        if plot:
            pylab.figure()
            pylab.clf()
            pylab.title('Planners value function')
            self.V_f.plot(['x', 1], showdata=True)
            pylab.show()

            pylab.figure()
            pylab.clf()
            pylab.title('Planners policy function')
            self.W_f.plot(['x', 1], showdata=True)
            pylab.ylim(0,storage.K)
            pylab.xlim(0,storage.K)
            pylab.show()


    #------------------------------------------------------------------------------------------------#
    #                                                                                                #
    #                 Q-learning - planners problem                                                  #
    #                                                                                                #
    #------------------------------------------------------------------------------------------------#

    def Q_learn_batch_planner(self, sim, W_f_old, QT=10, delta=0, ITER=20, V_f=0):

        """

        Solve planners storage problem by Q learning

        Parameters
        -----------

        sim : Simulation
            Simulation instance
        W_f_old :
            Initial policy function
        V_f :
            Value function
        W_f :
            Policy function

        Returns
        ----------

        W_f :
            Policy function
        V_f :
            Value function
        Q_f :
            Q function
        """

        # ------------------
        #   Initialization
        # ------------------

        tic = time.time()

        # State space grid

        points = 1000
        radius = 0.02
        grid = get_centers(sim.X_t1, points, radius, scale=True)
        points = grid.shape[0]
        print 'State grid points: ' + str(points)

        if sim.X_t1.shape[0] < 40000:
            ms = 4
        else:
            ms = 85

        # Q function
        Q_f = BIG_Tilecode(3, [QT, QT, 8], int(120/QT), min_sample=ms)

        # Policy function
        W_f = SMALL_Tilecode_m(points, 2, [13, 13], 10)
        W_f.fit(grid, np.zeros(points))

        # Value function
        if delta == 0:
            V_f = SMALL_Tilecode(points, 2, [12, 12], 10)
            #v_hat = self.V_f.predict(grid)
            #V_f.fit(grid, v_hat)
            V_f.fit(grid, np.zeros(points))
        else:
            V_f = self.V_f

        # ------------------
        #   Q-learning
        # ------------------

        for j in range(ITER):

            # Q values
            Q = sim.series['SW'] + self.beta * V_f.predict(sim.X_t1, cores=self.cores)

            # Fit Q function
            Q_f.fit(sim.XA_t, Q, cores=self.cores, copy=True)

            # Optimise Q function
            [V_f, W_f, ERROR] = self.planner_maximise(W_f, V_f, Q_f, grid, W_f_old, delta=delta)

        toc = time.time()

        print 'Solve time: ' + str(toc - tic)

        self.V_f = V_f

        return [W_f, V_f, Q_f, sim]

    def planner_maximise(self, W_f, V_f, Q_f, grid, W_f_old, delta=0):

        """
        Maximises current Q-function for a subset of state space points and returns new value and policy functions

        Parameters
        -----------

        W_f :
            Current Policy function
        V_f :
            Value function
        Q_f :
            Q function

        grid : array, shape=(N, D)
            State space grid

        W_f_old :
            Old policy function

        Returns
        -----------

        V_f :
            Policy function
        W_f :
            Policy function
        ERROR: float
            Mean absolute deviation

        """
        tic = time.time()

        if delta == 0:
            [W_opt, V, state] = Q_f.opt(grid)
        else:
            K = np.max(grid[:,0])
            N = grid.shape[0]
            w_min = np.maximum(W_f_old.predict(grid) - delta * K, 0)
            w_max = np.minimum(W_f_old.predict(grid) + delta * K, grid[:,0])
            [W_opt, V, state] = Q_f.opt_finetune(grid, w_min, w_max)

        W_opt_old = W_f.predict(state)
        V_old = V_f.predict(state)

        V_f.fit(state, V)
        W_f.fit(state, W_opt, sgd=1, eta=0.4, n_iters=1, scale=0)

        policy_error = np.mean(abs(W_opt_old - W_opt))
        value_error = np.mean(abs(V_old - V))

        toc = time.time()

        print 'Maximisation time: ' + str(toc - tic)
        print 'Value function change: ' + str(round(value_error, 4)) + ', Policy change: ' + str(round(policy_error, 4))

        #W_f.plot(['x', 1], showdata=True)
        #W_f_old.plot(['x', 1])
        #pylab.show()

        #V_f.plot(['x', 1], showdata=True)
        #pylab.show()

        return [V_f, W_f, value_error]
