from distutils.core import setup
from distutils.extension import Extension
from Cython.Distutils import build_ext
import numpy as np

flags = ["-ffast-math", "-march=native" ]

setup(
  name = 'Storage class',
  cmdclass = {'build_ext': build_ext},
  include_dirs = [np.get_include()], 
  ext_modules = [Extension("storage_class", ["storage_class.pyx"], extra_compile_args=flags, libraries=["m"])]
)

setup(
  name = 'Utility class',
  cmdclass = {'build_ext': build_ext},
  include_dirs = [np.get_include(),"."], 
  ext_modules = [Extension("utility_class", ["utility_class.pyx"], extra_compile_args=flags, libraries=["m"])]
) 

setup(
  name = 'Users class',
  cmdclass = {'build_ext': build_ext},
  include_dirs = [np.get_include(),"."], 
  ext_modules = [Extension("users_class", ["users_class.pyx"], extra_compile_args=flags, libraries=["m"])]
)

setup(
  name = 'grid builder',
  cmdclass = {'build_ext': build_ext},
  include_dirs = [np.get_include(),"."], 
  ext_modules = [Extension("grid_builder", ["grid_builder.pyx"], extra_compile_args=flags, libraries=["m"])]
)

setup(
  name = 'solve',
  cmdclass = {'build_ext': build_ext},
  include_dirs = [np.get_include(),"."], 
  ext_modules = [Extension("solve", ["solve.pyx"], extra_compile_args=flags, libraries=["m"])]
)

setup(
  name = 'Tile coding',
  cmdclass = {'build_ext': build_ext},
  include_dirs = [np.get_include(), "."], 
  ext_modules = [Extension("tilecode_class", ["tilecode_class.pyx"], extra_compile_args=flags, libraries=["m"])]
) 

setup(
  name = 'Simulation class',
  cmdclass = {'build_ext': build_ext},
  include_dirs = [np.get_include(), "."], 
  ext_modules = [Extension("simulation_class", ["simulation_class.pyx"], extra_compile_args=flags, libraries=["m"])]
) 

