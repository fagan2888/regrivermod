rm *.c
rm *.so
rm *.swp
rm *.html
rm -rf build
zip -r regrivermod.zip ~/Dropbox/Model/regrivermod
#python multyvac_setup.py
python setup2.py build_ext --inplace

