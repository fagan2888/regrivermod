from distutils.core import setup
from distutils.extension import Extension
from Cython.Distutils import build_ext
import numpy as np

extNames = ['storage', 'utility', 'users', 'scattergrid', 'solve', 'tilecode', 'simulation']

def makeExtension(extName):
    extPath = extName + ".pyx"
    return Extension(
        extName,
        [extPath],
        include_dirs = [np.get_include(),".."],
        extra_compile_args = ["-ffast-math", "-march=native" ],
        libraries = ["m",],
        )
extensions = [makeExtension(name) for name in extNames]

setup(
  name = 'regrivermod',
  packages =["regrivermod"],
  cmdclass = {'build_ext': build_ext}, 
  ext_modules = extensions, 
) 

